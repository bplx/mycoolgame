const WIDTH = 800
const HEIGHT = 600

var config = {
  type: Phaser.AUTO,
  width: WIDTH,
  height: HEIGHT,
  physics: {
    default: 'arcade',
    arcade: {
      gravity: { y: 0 },
      debug: true
    }
  },
  scene: {
    preload: preload,
    create: create,
    update: update
  }
};

var game = new Phaser.Game(config);

function getDirectionFromMXMY(MX, MY) {
  let dir;
  if (MX == 1 && MY == 0) {
    dir = "right"
  } else if (MX == 1 && MY == 1) {
    dir = "upright"
  }
  return dir;
}


function preload() {
  this.load.image('bg', 'img/bg.png');
  this.load.image('player1Sprite', 'img/player.png');
  this.load.image('puckSprite', 'img/ball.png');
  this.load.image('player2Goal', 'img/p2goal.png');
  this.load.image('player1Goal', 'img/p1goal.png');
}

// Initially make the vars

let cursors, player1, player2, ball, kbd, p2goal, p1goal, goalHappening, goalText

function create() {
  // Create the background.
  this.add.image(0, 0, 'bg').setOrigin(0, 0)

  // Create our way to read the keys.
  // kbd = Phaser.Input.Keyboard.KeyboardPlugin()

  // Create our way to read the cursor keys.
  cursors = this.input.keyboard.createCursorKeys();

  // Create the player 1.
  player1 = {
    obj: this.physics.add.sprite(200, 300, 'player1Sprite')
      .setCollideWorldBounds(true)
      .setDamping(true)
      .setDrag(0.1),
    speed: 300,
    hasPuck: false,
    dir: "none",
    kbd: {
      shoot: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.PERIOD)
    },
    text: this.add.text(20, 50, "P1", { color: "#000", }),
    score: 0,
  }
  player1.obj.body.setMaxVelocity(player1.speed)

  // Create the player 2.
  player2 = {
    obj: this.physics.add.sprite(600, 300, 'player1Sprite')
      .setCollideWorldBounds(true)
      .setDamping(true)
      .setDrag(0.1),
    speed: 300,
    hasPuck: false,
    dir: "none",
    kbd: {
      shoot: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SHIFT),
      up: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W),
      left: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A),
      down: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S),
      right: this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D),
    },
    text: this.add.text(20, 50, "P2", { color: "#000", }),
    score: 0,
  }
  player2.obj.body.setMaxVelocity(player2.speed)

  // Create the ball.
  puck = this.physics.add.sprite(400, 300, 'puckSprite')
    .setCollideWorldBounds(true)
    .setDamping(true)
    .setDrag(0.9)
    .setBounce(1, 1);


  // Goals.
  p1goal = this.physics.add.sprite(700, 300, "player1Goal").setScale(3)
  p1goal.body.immovable = true
  p2goal = this.physics.add.sprite(100, 300, "player2Goal").setScale(3)
  p2goal.body.immovable = true

  // Goal text!
  goalText = this.add.text(400, 300, "GOAL!!!", { color: "#000" }).setScale(2)
  goalText.visible = false

  // Player1 collisions.
  this.physics.add.collider(player1.obj, puck, () => {
    if (!player2.hasPuck) {
      player1.hasPuck = true;
    } else if (player2.hasPuck) {
      player2.hasPuck = false;
      player1.hasPuck = true;
    }
  });
  this.physics.add.collider(player1.obj, player2.obj, () => {
    if (player2.hasPuck) {
      player2.hasPuck = false;
      player1.hasPuck = true;
    }
    if (player1.hasPuck) {
      player1.hasPuck = false;
      player2.hasPuck = true;
    }
  })

  // Player2 collisions.
  this.physics.add.collider(player2.obj, puck, () => {
    if (!player1.hasPuck) {
      player2.hasPuck = true;
    } else if (player1.hasPuck) {
      player1.hasPuck = false;
      player1.hasPuck = true;
    }
  });
  function goal() {
    let timer = 2000;
    goalHappening = true

    player1.obj.setAcceleration(0);
    player2.obj.setAcceleration(0);
    player1.obj.setVelocity(0);
    player2.obj.setVelocity(0);

    puck.setVelocity(0);
    puck.setAcceleration(0);

    this.time.addEvent({
      delay: 2000, callback: () => {
        player1.x = 200;
        player1.y = 300;
        player2.x = 600;
        player2.y = 300;
      },
    })
  }

  // Goal collisions.
  this.physics.add.collider(puck, p1goal, () => {
    if (!player2.hasPuck && !player1.hasPuck) {

      console.log("p2 SCORES!!!!!!!!!!!!!!!!!!!!!!");

      goalText.setText("P2 GOAL!!!");
      goalText.visible = true
      goal()
    }
  })

}

function update() {

  // Input block.
  if (!goalHappening) {

    // Input for Player 1.
    if (cursors.left.isDown) {
      player1.obj.setAccelerationX(-player1.speed);
    } else if (cursors.right.isDown) {
      player1.obj.setAccelerationX(player1.speed);
    } else {
      player1.obj.setAccelerationX(0);
    }
    if (cursors.up.isDown) {
      player1.obj.setAccelerationY(-player1.speed);
    } else if (cursors.down.isDown) {
      player1.obj.setAccelerationY(player1.speed);
    } else {
      player1.obj.setAccelerationY(0);
    }
    if (player1.kbd.shoot.isDown) {
      if (player1.hasPuck) {
        player1.hasPuck = false
        console.log(this.physics.velocityFromRotation(player1.obj.body.angle * (180 / Math.PI), 600))
        puck.setVelocity(
          this.physics.velocityFromRotation(player1.obj.body.angle, 600).x,
          this.physics.velocityFromRotation(player1.obj.body.angle, 600).y
        )
        console.log("P1 shot puck!")
      }
    }

    // Input for Player 2.
    if (player2.kbd.left.isDown) {
      player2.obj.setAccelerationX(-player2.speed);
    } else if (player2.kbd.right.isDown) {
      player2.obj.setAccelerationX(player2.speed);
    } else {
      player2.obj.setAccelerationX(0);
    }
    if (player2.kbd.up.isDown) {
      player2.obj.setAccelerationY(-player2.speed);
    } else if (player2.kbd.down.isDown) {
      player2.obj.setAccelerationY(player2.speed);
    } else {
      player2.obj.setAccelerationY(0);
    }
    if (player2.kbd.shoot.isDown) {
      if (player2.hasPuck) {
        player2.hasPuck = false
        console.log(this.physics.velocityFromRotation(player2.obj.body.angle * (180 / Math.PI), 600))
        puck.setVelocity(
          this.physics.velocityFromRotation(player2.obj.body.angle, 600).x,
          this.physics.velocityFromRotation(player2.obj.body.angle, 600).y
        )
        console.log("P2 shot puck!")
      }
    }

  }

  // Puck logic.
  if (player1.hasPuck) {
    puck.x = player1.obj.x
    puck.y = player1.obj.y
    puck.setVelocity(0, 0);
    puck.setAcceleration(0, 0)
  }

  if (player2.hasPuck) {
    puck.x = player2.obj.x
    puck.y = player2.obj.y
    puck.setVelocity(0, 0);
    puck.setAcceleration(0, 0)
  }

  // Text.
  player1.text.x = player1.obj.x
  player1.text.y = player1.obj.y - 40
  player2.text.x = player2.obj.x
  player2.text.y = player2.obj.y - 40
}

function render() {
  game.debug.cameraInfo(game.camera, 32, 32);
}
